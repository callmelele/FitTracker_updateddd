﻿function toggleTabs(activeTab, inactiveTab = null) {
    if (inloggStatus !== "yes") {
        window.location.href = "/Home/LogIn"; 
        return;
    }

    const activeElement = document.getElementById(activeTab);

    if (activeElement.style.display === "block") {
        activeElement.style.display = "none";
    } else {
        activeElement.style.display = "block";
        if (inactiveTab) {
            const inactiveElement = document.getElementById(inactiveTab);
            inactiveElement.style.display = "none";
        }
    }
}

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("LoginTab").style.display = "none";

    document.querySelector(".profileImage").addEventListener("click", function () {
        toggleTabs("LoginTab");
    });
});
