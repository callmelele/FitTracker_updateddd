using System.Diagnostics;
using FitTrack.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
//using System.Data.SqlClient;
using System;
using System.Data;
using Microsoft.Data.SqlClient;


namespace FitTrack.Controllers
{
    public class HomeController : Controller
    {
        private readonly IWebHostEnvironment environment;


        public HomeController(IWebHostEnvironment env)
        {
            environment = env;
        }

        private string GetConnectionString(string databaseFileName)
        {
            return environment.IsDevelopment()
                ? @$"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename={environment.ContentRootPath}\{databaseFileName};Integrated Security=True;Connect Timeout=15"
                : @$"Data Source=.\SQLEXPRESS;Integrated Security=SSPI;AttachDBFilename={environment.ContentRootPath}{databaseFileName};User Instance=true;Connect Timeout=15";
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult HomePage()
        {
			DataTable localTbl = new DataTable();
			using (SqlConnection connection = new SqlConnection(GetConnectionString("FitTracker.mdf")))

			{
				connection.Open();
				string query = "SELECT * FROM Users";
				SqlDataAdapter sqlDa = new SqlDataAdapter(query, connection);
				sqlDa.Fill(localTbl);
			}

			ViewData["Inloggad"] = HttpContext.Session.GetString(Inloggad) ?? "no";
			return View(localTbl);
        }

		public ActionResult LogIn()
        {
            return View();
        }

		public ActionResult CreateWo()
		{
			return View();
		}

		public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(IFormFile file)
        {
            using (SqlConnection connection = new SqlConnection(GetConnectionString("FitTracker.mdf")))
            {
                connection.Open();
                string query = "INSERT INTO Users (F�rnamn, Username, PSW, picture) VALUES(@Firstname, @Usern, @Pswd, @Picture)";
                SqlCommand sqlCmd = new SqlCommand(query, connection);
                sqlCmd.Parameters.AddWithValue("@Firstname", Request.Form["F�rnamn"].ToString());
                sqlCmd.Parameters.AddWithValue("@Usern", Request.Form["Username"].ToString());
                sqlCmd.Parameters.AddWithValue("@Pswd", Request.Form["Password"].ToString());

                if (file == null)
                {
                    sqlCmd.Parameters.AddWithValue("@Picture", "dummy.png");
                    sqlCmd.ExecuteReader();
                }
                else
                {
                    sqlCmd.Parameters.AddWithValue("@Pic", file.FileName);
                    var filePath = Path.Combine(environment.ContentRootPath, "wwwroot/Images/", file.FileName);

                    using var stream = System.IO.File.Create(filePath);
                    file.CopyTo(stream);
                    sqlCmd.ExecuteReader();

                }
            }
            return RedirectToAction("HomePage");
        }

        public const string UserID = "_personID";
        public const string UserName = "_Username";
        public const string Inloggad = "_InloggStatus";


        [HttpPost]
        public IActionResult LogIn_check()
        {
            DataTable Users = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(GetConnectionString("FitTracker.mdf")))
            {
                sqlCon.Open();
                string query = "SELECT * FROM Users WHERE Username = @Usern AND PSW = @Pswd";
                SqlDataAdapter sqlDa = new SqlDataAdapter(query, sqlCon);
                sqlDa.SelectCommand.Parameters.AddWithValue("@Usern", Request.Form["Username"].ToString());
                sqlDa.SelectCommand.Parameters.AddWithValue("@Pswd", Request.Form["Password"].ToString());

                sqlDa.Fill(Users);
            }

            if (Users.Rows.Count > 0)
            {
                HttpContext.Session.SetInt32(UserID, (int)Users.Rows[0]["PersonID"]);
                HttpContext.Session.SetString(UserName, (string)Users.Rows[0]["Username"]);
                HttpContext.Session.SetString(Inloggad, "yes");
                ViewData["PersonID"] = HttpContext.Session.GetInt32("_personID");
                ViewData["Username"] = HttpContext.Session.GetString("_Uname");
                ViewData["text"] = HttpContext.Session.GetString("_InloggStatus");
                ViewData["text"] = "logged In";
                return RedirectToAction("HomePage");

            }
            else
            {
                ViewData["text"] = "ej inloggad";
                return RedirectToAction("LogIn");
            }
        }







        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

    }
}
